# arago_hiro_6_mars_importer
Python script to import MARS model for HIRO version 6.x


License
-----

This tool is licensed under the MIT license: https://opensource.org/licenses/MIT
